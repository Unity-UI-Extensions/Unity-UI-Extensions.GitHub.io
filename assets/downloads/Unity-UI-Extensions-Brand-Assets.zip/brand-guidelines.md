# Unity UI Extensions — Brand Guidelines

**Version:** 3.0 relaunch · **Identity system:** Neon Arcade (locked) · **Maintainer:** Simon "darkside" Jackson (@SimonDarksideJ)

> Two packages. One ecosystem.

This document is the single source of truth for how Unity UI Extensions looks, sounds and feels. If a decision is not covered here, default to the principles: high-energy, neon-on-black, technically precise, every claim backed by a number.

---

## 1. Brand story & positioning

### What it is
Unity UI Extensions is the flagship open-source UI control collection for Unity. It has been community-driven and battle-tested since 2015. The 3.0 relaunch reframes the project as a **two-package ecosystem** presented as co-equals under one unifying version banner: **3.0**.

- **uGUI package** — `com.unity.uiextensions`, version **3.0.0-pre.1**. This is the V3 release.
- **UI Toolkit package** — `com.unity.uitoolkitextensions`, version **1.0.0-pre.1**.

The lead line is locked: **"Two packages. One ecosystem."** Neither package is the junior partner. The uGUI package is the deep, decade-proven library for the established UI system; the UI Toolkit package is the modern, USS-themable, data-driven companion for Unity 6's runtime UI. They sit side by side under the 3.0 banner.

### The numbers (use these exactly)
- **120 UI controls total** (100 uGUI + 20 UI Toolkit).
- **29 example projects/scenes total** (21 uGUI + 8 UI Toolkit).
- **Battle-tested since 2015.**
- **100% free and open source.** Licences: BSD-3-Clause (uGUI), MIT (UI Toolkit).

### Positioning
Primary headlines: **"Stop Rebuilding UI From Scratch"** and **"Supercharge Your Unity UI".**

Sub-line: *120 battle-tested UI controls for Unity uGUI and UI Toolkit. Open source, community-driven, production-ready.*

### Value pillars
1. **Ship weeks faster** — the controls you would build anyway, polished and edge-case handled.
2. **Production battle-tested** — a decade of community use, bug reports and fixes since 2015.
3. **UPM-first distribution** — OpenUPM or git URL, clean dependency management.
4. **Fully customisable** — Inspector-exposed for uGUI, USS-themable for UI Toolkit.
5. **Examples included** — 29 playable example scenes.
6. **Open contribution** — BSD-3 + MIT, PRs welcome, every contributor credited.

**The offer:** free, no lock-in, community-owned.

---

## 2. Logo concept & meaning

The logo is a **dark rounded-square tile** holding a **"U" monogram**.

- **Tile:** near-black (`#0a0a14` on a `#050508` field). Rounded square — the only place softer corners are sanctioned, and only gently.
- **The U monogram:** built from **two vertical bars plus a bottom crossbar**. It reads as a single letter **U** — standing for **Unity + UI Extensions**.
- **Fill:** the **signature brand gradient** — `linear-gradient(135deg, #ff0099 0%, #00ffee 100%)`. Magenta at top-left, cyan at bottom-right.

### Meaning
The magenta→cyan gradient is the whole story in one mark: **magenta = the uGUI package, cyan = the UI Toolkit package**, fused into one continuous form. Two packages, one ecosystem — visualised.

### Wordmark
Set **"UNITY UI EXTENSIONS"** in **Orbitron**, uppercase, letter-spacing ~0.08–0.1em. On dark backgrounds the wordmark may carry a subtle magenta glow (`text-shadow: 0 0 20px rgba(255,0,153,0.6)`).

### Logo do / don't
- **Do** keep the gradient angle at 135deg, magenta→cyan, in that order.
- **Do** preserve clear space of at least one bar-width around the tile.
- **Don't** recolour the monogram to a flat single colour, reverse the gradient direction, add soft drop-shadows, or round the tile into a circle.
- **Don't** stretch, skew or apply bevels. Glow is the only permitted depth effect.

---

## 3. Colour system

The colour rule is the backbone of the whole identity:

> **uGUI content uses MAGENTA. UI Toolkit content uses CYAN. The master brand uses the magenta→cyan gradient.**

Never colour a uGUI control cyan or a UI Toolkit control magenta. The duality is load-bearing — it is how a reader instantly knows which package they are looking at.

### Foundations (neon-on-black)
| Token | Hex / value | Where to use |
|---|---|---|
| Background (primary) | `#050508` | Page background, the canvas everything sits on |
| Background (raised) | `#08080e` | Raised panels, nav bar, cards behind content |
| Surface (faint) | `rgba(255,0,153,0.04)` | Default card/panel fill |
| Surface (raised) | `rgba(255,0,153,0.08)` | Hover/active panel fill |
| Overlay | `rgba(255,0,153,0.12)` | Modal scrims, strongest magenta tint |

### Text
| Token | Hex | Where to use |
|---|---|---|
| Text primary | `#ffffff` | Body copy, headings on dark |
| Text secondary | `#dd88ff` | Sub-labels, captions, secondary copy |
| Text muted | `#663388` | Disabled, metadata, fine print |
| Text inverse | `#050508` | Text on a magenta/cyan filled button |
| Code | `#00ffcc` / `#00ffee` | Inline code, code blocks, terminal output |

### Magenta — uGUI accent (also the primary brand accent)
| Token | Value | Where to use |
|---|---|---|
| Magenta | `#ff0099` | Primary accent; all uGUI controls, links, focus |
| Magenta deep | `#bb0077` | Pressed states, deeper accent fills |
| uGUI gradient | `linear-gradient(135deg,#ff66cc 0%,#880055 100%)` | uGUI buttons, package cards, headers |
| uGUI glow | `0 0 30px rgba(255,0,153,.60)` | Glow on uGUI interactive elements |

### Cyan — UI Toolkit accent
| Token | Value | Where to use |
|---|---|---|
| Cyan | `#00ffee` | All UI Toolkit controls, accents, focus |
| Cyan deep | `#007788` | Pressed states, deeper cyan fills |
| UITK gradient | `linear-gradient(135deg,#00ffee 0%,#0044aa 100%)` | UI Toolkit buttons, package cards, headers |
| UITK glow | `0 0 30px rgba(0,255,238,.60)` | Glow on UI Toolkit interactive elements |

### Signature brand gradient
| Token | Value | Where to use |
|---|---|---|
| Brand gradient | `linear-gradient(135deg,#ff0099 0%,#00ffee 100%)` | The logo mark, the master brand, hero moments that represent the whole ecosystem |

### Borders
| Token | Value | Where to use |
|---|---|---|
| Border (low) | `rgba(255,0,153,0.18)` | Default panel/control borders |
| Border (strong) | `rgba(255,0,153,0.35)` | Hover borders, emphasised dividers |

---

## 4. Typography

Four faces, each with one job. Do not introduce additional families.

| Face | Role | Casing & spacing |
|---|---|---|
| **Orbitron** | Display headings + logo wordmark | UPPERCASE, letter-spacing ~0.08–0.1em |
| **Space Grotesk** | Secondary headings, section titles | Title case, normal spacing |
| **Inter** | Body copy, UI labels | Sentence case |
| **JetBrains Mono** | Code, version chips, terminal | As written; version chips like `3.0.0-pre.1` |

**Font stack for SVG/CSS fallback:** `'Orbitron', 'Space Grotesk', system-ui, sans-serif` for display; `'Inter', system-ui, sans-serif` for body; `'JetBrains Mono', monospace` for code.

**Rules**
- Orbitron is reserved for impact — hero titles, the wordmark, package names. Never set long body copy in Orbitron.
- Space Grotesk bridges display and body for sub-heads.
- Keep letter-spacing tight on body (Inter) and generous on Orbitron only.
- Version numbers and package IDs always render in JetBrains Mono.

---

## 5. Iconography & imagery style

- **Neon-on-black.** Every visual lives on `#050508` / `#08080e`. No white or light backgrounds anywhere in the brand surface.
- **Glow, not fill.** Icons are line-based with a thin neon stroke in the relevant accent (magenta for uGUI, cyan for UI Toolkit, gradient for master brand) and a soft outer glow.
- **Scanlines.** A faint horizontal scanline texture overlays large dark surfaces: `repeating-linear-gradient(0deg, rgba(255,0,153,0.025) 0px, rgba(255,0,153,0.025) 1px, transparent 1px, transparent 4px)`. Keep it subtle — it should read as atmosphere, never as stripes.
- **Screenshots:** show controls running on the dark canvas, accented in the correct package colour, with a thin glowing border.
- **No stock photography, no gradients outside the sanctioned set, no skeuomorphism.**

---

## 6. UI styling cues

- **Sharp corners.** Radius `2px` by default, up to `6px` maximum. Pills are ~`2px`. The smallest controls may be fully square (`0px`). The logo tile is the one exception that rounds more.
- **Glows, not soft drop-shadows.** Depth is expressed as coloured outer glow in the element's accent colour. Never use grey/black blurred drop-shadows.
  - Small glow: `0 0 10px rgba(255,0,153,0.25)`
  - Default glow: `0 0 24px rgba(255,0,153,0.35)`
  - Large glow: `0 0 48px rgba(255,0,153,0.45)`
- **Borders carry the accent** at low alpha; they brighten on hover/focus.
- **Buttons:** filled with the package gradient, inverse (`#050508`) label, accent glow on hover.
- **Focus rings:** brightened accent border (`rgba(255,0,153,0.70)` for magenta surfaces).

---

## 7. Motion & feel

- **Fast and snappy.** Standard transition: `0.18s cubic-bezier(0.4,0,0.2,1)`. Arcade reflexes, not corporate fades.
- **Glow pulse** for hero/package cards — a slow `~3s` ease-in-out breathing glow. Stagger the two package cards (offset ~1.5s) so magenta and cyan pulse in counterpoint.
- Motion should feel **electric and precise**: quick on interaction, gentle and rhythmic at rest.
- Respect `prefers-reduced-motion` — disable the glow pulse and slide animations when requested.

---

## 8. Voice & tone

Confident, punchy, developer-to-developer. Short sentences. Active voice. A little arcade swagger — but every claim is backed by a number. Not corporate, not hypey. Community pride throughout.

### Do say
- "Ship faster. Build better."
- "The controls you would build anyway are already here."
- "Two packages. One ecosystem."
- "100+ controls. 29 example scenes. Battle-tested since 2015."
- "Free, open source, community-owned. No lock-in."

### Don't say
- "The most revolutionary, game-changing UI solution ever created." *(overpromising adjectives with no proof)*
- "Synergise your development workflow paradigm." *(corporate fluff)*
- "Probably the best UI library — you'll love it!" *(hypey, unsubstantiated)*
- Em-dash salad and run-on sentences. Keep it tight.

### Rules
- Every superlative needs a number behind it.
- British spelling throughout: colour, customisable, optimise, behaviour, licence.
- Lead with the benefit, follow with the proof.

---

## 9. Accessibility & contrast (dark UI)

This is a dark, high-saturation palette. Guard legibility deliberately.

- **Body text:** use `#ffffff` on `#050508`/`#08080e` for primary reading copy — very high contrast, safe.
- **Secondary text** (`#dd88ff`) is for short labels and captions only, not long-form reading.
- **Muted text** (`#663388`) is low-contrast by design; restrict to metadata and disabled states, never essential information conveyed by that colour alone. [VERIFY against WCAG AA per usage size.]
- **Never rely on colour alone** to signal uGUI vs UI Toolkit — always pair the magenta/cyan cue with a text label or icon, so colour-blind users get the same information.
- **Neon accents on black** (`#ff0099`, `#00ffee`) are vivid; cyan in particular is bright on dark and reads well, magenta is strong enough for large text and UI accents. For small body text prefer `#ffffff` over a raw accent. [VERIFY exact ratios for any accent-coloured text below 18px.]
- **Focus states** must be visible without relying on the glow alone — keep a brightened solid border as well.
- **Glow is decorative.** Never encode meaning solely in a glow; pair with border, label, or shape.

---

## 10. Quick reference cheat-sheet

| Aspect | Value |
|---|---|
| Lead line | Two packages. One ecosystem. |
| Headlines | Stop Rebuilding UI From Scratch · Supercharge Your Unity UI |
| Background | `#050508` primary · `#08080e` raised |
| uGUI accent (magenta) | `#ff0099` (deep `#bb0077`) |
| UI Toolkit accent (cyan) | `#00ffee` (deep `#007788`) |
| Brand gradient (logo) | `linear-gradient(135deg,#ff0099,#00ffee)` |
| Text | `#ffffff` / `#dd88ff` / `#663388` · code `#00ffcc`/`#00ffee` |
| Display font | Orbitron — UPPERCASE, ~0.08–0.1em |
| Sub-head font | Space Grotesk |
| Body font | Inter |
| Code/chip font | JetBrains Mono |
| Corners | Sharp — 2px default, up to 6px, pills ~2px |
| Depth | Glow, not drop-shadow — `0 0 30px rgba(accent,.60)` |
| Texture | Faint horizontal scanlines `rgba(255,0,153,0.025)` |
| Motion | `0.18s cubic-bezier(0.4,0,0.2,1)` + slow glow pulse |
| Colour rule | uGUI = magenta · UI Toolkit = cyan · brand = gradient |
| Spelling | British (colour, customisable, optimise, behaviour) |
| Stats | 120 controls · 29 example scenes · since 2015 · 100% free |
| Licences | BSD-3 (uGUI) · MIT (UI Toolkit) |
