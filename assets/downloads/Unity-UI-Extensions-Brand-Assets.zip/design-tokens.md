# Unity UI Extensions — Design Tokens

The Neon Arcade design system, expressed in three formats: a **Markdown reference table**, a **JSON object**, and a **CSS `:root` custom-properties block**. Token names and hex values are authoritative and match the implemented theme.

> Colour rule: `--u*` tokens = uGUI (magenta), `--t*` tokens = UI Toolkit (cyan), `--brand-gradient` = master brand. Keep them on the right package.

---

## 1. Markdown table

### Foundations
| Token | Value | Usage |
|---|---|---|
| `--bg` | `#050508` | Primary page background |
| `--bg-2` | `#08080e` | Raised background (nav, panels) |
| `--surface` | `rgba(255,0,153,0.04)` | Default card/panel surface |
| `--surface-2` | `rgba(255,0,153,0.08)` | Hover/active surface |
| `--overlay` | `rgba(255,0,153,0.12)` | Modal scrim / strongest tint |

### Text
| Token | Value | Usage |
|---|---|---|
| `--text` | `#ffffff` | Primary text |
| `--text-2` | `#dd88ff` | Secondary text |
| `--text-muted` | `#663388` | Muted / disabled text |
| `--text-inv` | `#050508` | Text on filled accent buttons |
| `--text-code` | `#00ffcc` | Inline & block code |

### Borders
| Token | Value | Usage |
|---|---|---|
| `--border` | `rgba(255,0,153,0.18)` | Default border |
| `--border-2` | `rgba(255,0,153,0.35)` | Strong / hover border |
| `--border-focus` | `rgba(255,0,153,0.70)` | Focus ring |

### Accent (primary brand = magenta)
| Token | Value | Usage |
|---|---|---|
| `--accent` | `#ff0099` | Primary brand accent |
| `--accent-2` | `#bb0077` | Deep accent / pressed |
| `--accent-dim` | `rgba(255,0,153,0.14)` | Dim accent fill |

### uGUI — magenta
| Token | Value | Usage |
|---|---|---|
| `--u` | `#ff0099` | uGUI accent |
| `--u2` | `#880055` | uGUI deep (gradient end) |
| `--u3` | `rgba(255,0,153,0.05)` | uGUI faint tint |
| `--u-grad` | `linear-gradient(135deg, #ff66cc 0%, #880055 100%)` | uGUI gradient |
| `--u-glow` | `0 0 30px rgba(255,0,153,0.60), 0 0 70px rgba(255,0,153,0.25)` | uGUI glow |
| `--u-border` | `rgba(255,0,153,0.35)` | uGUI border |
| `--u-text` | `#ffccee` | uGUI tinted text |

### UI Toolkit — cyan
| Token | Value | Usage |
|---|---|---|
| `--t` | `#00ffee` | UI Toolkit accent |
| `--t2` | `#007788` | UI Toolkit deep |
| `--t3` | `rgba(0,255,238,0.05)` | UI Toolkit faint tint |
| `--t-grad` | `linear-gradient(135deg, #00ffee 0%, #0044aa 100%)` | UI Toolkit gradient |
| `--t-glow` | `0 0 30px rgba(0,255,238,0.60), 0 0 70px rgba(0,255,238,0.25)` | UI Toolkit glow |
| `--t-border` | `rgba(0,255,238,0.35)` | UI Toolkit border |
| `--t-text` | `#ccffff` | UI Toolkit tinted text |

### Master brand
| Token | Value | Usage |
|---|---|---|
| `--brand-gradient` | `linear-gradient(135deg, #ff0099 0%, #00ffee 100%)` | Logo mark, master-brand moments |

### Typography
| Token | Value | Usage |
|---|---|---|
| `--font-h` | `'Orbitron', 'Space Grotesk', system-ui, sans-serif` | Display headings + wordmark |
| `--font-sub` | `'Space Grotesk', system-ui, sans-serif` | Secondary headings |
| `--font-b` | `'Inter', system-ui, sans-serif` | Body |
| `--font-c` | `'JetBrains Mono', monospace` | Code / version chips |
| `--ls-display` | `0.09em` | Orbitron letter-spacing |

### Radius (sharp corners)
| Token | Value | Usage |
|---|---|---|
| `--r-xs` | `0px` | Fully square |
| `--r` | `2px` | Default corner |
| `--r-lg` | `4px` | Larger panels |
| `--r-xl` | `6px` | Maximum corner |
| `--r-pill` | `2px` | Pills |

### Glow / shadow (glow, not drop-shadow)
| Token | Value | Usage |
|---|---|---|
| `--sh-sm` | `0 0 10px rgba(255,0,153,0.25)` | Small glow |
| `--sh` | `0 0 24px rgba(255,0,153,0.35)` | Default glow |
| `--sh-lg` | `0 0 48px rgba(255,0,153,0.45)` | Large glow |

### Motion & layout
| Token | Value | Usage |
|---|---|---|
| `--ease` | `0.18s cubic-bezier(0.4,0,0.2,1)` | Standard transition |
| `--nav-h` | `62px` | Nav bar height |
| `--nav-bg` | `rgba(5,5,8,0.95)` | Nav bar background |
| `--pattern` | `repeating-linear-gradient(0deg, rgba(255,0,153,0.025) 0px, rgba(255,0,153,0.025) 1px, transparent 1px, transparent 4px)` | Scanline texture |

---

## 2. JSON

```json
{
  "color": {
    "bg": "#050508",
    "bg-2": "#08080e",
    "surface": "rgba(255,0,153,0.04)",
    "surface-2": "rgba(255,0,153,0.08)",
    "overlay": "rgba(255,0,153,0.12)",
    "text": "#ffffff",
    "text-2": "#dd88ff",
    "text-muted": "#663388",
    "text-inv": "#050508",
    "text-code": "#00ffcc",
    "border": "rgba(255,0,153,0.18)",
    "border-2": "rgba(255,0,153,0.35)",
    "border-focus": "rgba(255,0,153,0.70)",
    "accent": "#ff0099",
    "accent-2": "#bb0077",
    "accent-dim": "rgba(255,0,153,0.14)"
  },
  "ugui": {
    "u": "#ff0099",
    "u2": "#880055",
    "u3": "rgba(255,0,153,0.05)",
    "u-grad": "linear-gradient(135deg, #ff66cc 0%, #880055 100%)",
    "u-glow": "0 0 30px rgba(255,0,153,0.60), 0 0 70px rgba(255,0,153,0.25)",
    "u-border": "rgba(255,0,153,0.35)",
    "u-text": "#ffccee"
  },
  "uitoolkit": {
    "t": "#00ffee",
    "t2": "#007788",
    "t3": "rgba(0,255,238,0.05)",
    "t-grad": "linear-gradient(135deg, #00ffee 0%, #0044aa 100%)",
    "t-glow": "0 0 30px rgba(0,255,238,0.60), 0 0 70px rgba(0,255,238,0.25)",
    "t-border": "rgba(0,255,238,0.35)",
    "t-text": "#ccffff"
  },
  "brand": {
    "gradient": "linear-gradient(135deg, #ff0099 0%, #00ffee 100%)"
  },
  "font": {
    "display": "'Orbitron', 'Space Grotesk', system-ui, sans-serif",
    "sub": "'Space Grotesk', system-ui, sans-serif",
    "body": "'Inter', system-ui, sans-serif",
    "code": "'JetBrains Mono', monospace",
    "letter-spacing-display": "0.09em"
  },
  "radius": {
    "xs": "0px",
    "base": "2px",
    "lg": "4px",
    "xl": "6px",
    "pill": "2px"
  },
  "glow": {
    "sm": "0 0 10px rgba(255,0,153,0.25)",
    "base": "0 0 24px rgba(255,0,153,0.35)",
    "lg": "0 0 48px rgba(255,0,153,0.45)"
  },
  "motion": {
    "ease": "0.18s cubic-bezier(0.4,0,0.2,1)"
  },
  "layout": {
    "nav-h": "62px",
    "nav-bg": "rgba(5,5,8,0.95)",
    "scanline-pattern": "repeating-linear-gradient(0deg, rgba(255,0,153,0.025) 0px, rgba(255,0,153,0.025) 1px, transparent 1px, transparent 4px)"
  }
}
```

---

## 3. CSS `:root`

```css
:root {
  /* ── Foundations ───────────────────────────── */
  --bg:            #050508;
  --bg-2:          #08080e;
  --surface:       rgba(255,0,153,0.04);
  --surface-2:     rgba(255,0,153,0.08);
  --overlay:       rgba(255,0,153,0.12);

  /* ── Text ──────────────────────────────────── */
  --text:          #ffffff;
  --text-2:        #dd88ff;
  --text-muted:    #663388;
  --text-inv:      #050508;
  --text-code:     #00ffcc;

  /* ── Borders ───────────────────────────────── */
  --border:        rgba(255,0,153,0.18);
  --border-2:      rgba(255,0,153,0.35);
  --border-focus:  rgba(255,0,153,0.70);

  /* ── Accent (primary brand = magenta) ──────── */
  --accent:        #ff0099;
  --accent-2:      #bb0077;
  --accent-dim:    rgba(255,0,153,0.14);

  /* ── uGUI · MAGENTA ────────────────────────── */
  --u:             #ff0099;
  --u2:            #880055;
  --u3:            rgba(255,0,153,0.05);
  --u-grad:        linear-gradient(135deg, #ff66cc 0%, #880055 100%);
  --u-glow:        0 0 30px rgba(255,0,153,0.60), 0 0 70px rgba(255,0,153,0.25);
  --u-border:      rgba(255,0,153,0.35);
  --u-text:        #ffccee;

  /* ── UI Toolkit · CYAN ─────────────────────── */
  --t:             #00ffee;
  --t2:            #007788;
  --t3:            rgba(0,255,238,0.05);
  --t-grad:        linear-gradient(135deg, #00ffee 0%, #0044aa 100%);
  --t-glow:        0 0 30px rgba(0,255,238,0.60), 0 0 70px rgba(0,255,238,0.25);
  --t-border:      rgba(0,255,238,0.35);
  --t-text:        #ccffff;

  /* ── Master brand gradient (the logo mark) ─── */
  --brand-gradient: linear-gradient(135deg, #ff0099 0%, #00ffee 100%);

  /* ── Typography ────────────────────────────── */
  --font-h:        'Orbitron', 'Space Grotesk', system-ui, sans-serif;
  --font-sub:      'Space Grotesk', system-ui, sans-serif;
  --font-b:        'Inter', system-ui, sans-serif;
  --font-c:        'JetBrains Mono', monospace;
  --ls-display:    0.09em;

  /* ── Radius (sharp corners) ────────────────── */
  --r-xs:  0px;
  --r:     2px;
  --r-lg:  4px;
  --r-xl:  6px;
  --r-pill: 2px;

  /* ── Glow (not drop-shadow) ────────────────── */
  --sh-sm: 0 0 10px rgba(255,0,153,0.25);
  --sh:    0 0 24px rgba(255,0,153,0.35);
  --sh-lg: 0 0 48px rgba(255,0,153,0.45);

  /* ── Motion & layout ───────────────────────── */
  --ease:   0.18s cubic-bezier(0.4,0,0.2,1);
  --nav-h:  62px;
  --nav-bg: rgba(5,5,8,0.95);
  --pattern: repeating-linear-gradient(0deg,
               rgba(255,0,153,0.025) 0px,
               rgba(255,0,153,0.025) 1px,
               transparent 1px,
               transparent 4px);
}
```
