# Unity UI Extensions — Logo Usage

The Unity UI Extensions mark is a dark rounded-square tile holding a **U monogram** — two vertical bars plus a bottom crossbar — filled with the signature **135deg magenta -> cyan** gradient (`#ff0099 -> #00ffee`). The U stands for **Unity + UI Extensions**.

**Two packages. One ecosystem.** The master brand always uses the magenta->cyan gradient. (uGUI content leans magenta `#ff0099`; UI Toolkit content leans cyan `#00ffee` — but the logo itself stays on the full gradient.)

---

## File inventory

| File | Size / viewBox | Use |
|------|----------------|-----|
| `logo-icon-square.svg` | 256 x 256 | App icon / favicon / avatar tile. Refined tile + U monogram + inner glow. |
| `logo-primary.svg` | 512 x 512 | Primary mark. Tile + monogram with a soft outer glow halo. Hero, splash, social card. |
| `logo-wordmark-horizontal.svg` | 1280 x 320 | Horizontal lockup: icon tile + `UNITY UI EXTENSIONS` wordmark + `3.0` version chip. Headers, README banner, docs nav. |
| `logo-monochrome.svg` | 512 x 512 | Single flat `#ffffff` mark on transparent background. One-colour print, stamps, watermarks, low-contrast placements. |

All files are standalone SVG with embedded gradient defs and transparent backgrounds (except the tile fill itself). No external assets or fonts are required to render the shapes; text uses the font stack `Orbitron, 'Space Grotesk', system-ui, sans-serif`.

---

## Clear space

Keep a margin around the mark equal to the **height of one vertical bar of the U** (roughly 25% of the tile height). Nothing — text, other logos, UI chrome, or the edge of the canvas — should intrude into this zone.

```
  +---------------------------+
  |        clear space        |
  |     +---------------+     |
  |     |   [ U tile ]  |     |
  |     +---------------+     |
  |        clear space        |
  +---------------------------+
```

For the horizontal wordmark, measure clear space from the **tile**, not the text.

---

## Minimum sizes

| Asset | Minimum |
|-------|---------|
| Icon / primary tile | **24 px** square (digital). Below this the U monogram loses definition. |
| Horizontal wordmark | **160 px** wide (digital), or **24 mm** wide (print). Below this the `3.0` chip and wordmark stop being legible. |
| Monochrome mark | **20 px** square. |

When space is tight, drop to the **icon-only** tile rather than shrinking the full wordmark.

---

## Variants

- **On dark (default):** Use `logo-primary.svg` or `logo-icon-square.svg`. The mark is designed for the Neon Arcade dark palette (`#050508` / `#08080e`). Glows read correctly only on dark.
- **On light:** Use the dark tile mark as-is — the `#0a0a14` tile keeps the gradient U legible on light backgrounds. Do **not** place the gradient U directly on white without its tile.
- **Monochrome:** Use `logo-monochrome.svg` (flat `#ffffff`) for single-colour contexts, low contrast, or print. A `#050508`/black variant may be produced from the same geometry by swapping the fill.

---

## Correct usage

- Keep the magenta->cyan gradient direction at **135deg** (magenta top-left, cyan bottom-right).
- Preserve the tile's dark fill behind the gradient U.
- Keep corners **sharp** (small radius) — this is a Neon Arcade rule.
- Use glows, never soft grey drop-shadows.
- Use the wordmark font stack starting with **Orbitron**, uppercase, letter-spaced.

## Incorrect usage

- Do **not** recolour the U to a single flat colour (use the monochrome file instead).
- Do **not** reverse the gradient (cyan -> magenta) or rotate it away from 135deg.
- Do **not** place the gradient U on a busy photo or light background without its dark tile.
- Do **not** add soft drop-shadows, bevels, or rounded "squishy" corners.
- Do **not** stretch, skew, or change the proportions of the tile or the U.
- Do **not** re-typeset the wordmark in a different typeface or sentence case.
- Do **not** recolour the `3.0` version chip or change its text.
